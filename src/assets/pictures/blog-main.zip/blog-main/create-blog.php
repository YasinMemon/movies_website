<?php
session_start();
require 'config.php';

if ($_SESSION['role'] != 'admin') {
    header('Location: dashboard.php'); // Only admins can access
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author = 'Admin'; // Admin name or from session

    $stmt = $pdo->prepare("INSERT INTO blogs (title, content, author) VALUES (?, ?, ?)");
    $stmt->execute([$title, $content, $author]);

    header('Location: dashboard.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Blog</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>
<body>
    <h2>Create a New Blog</h2>
    <form method="POST" action="">
        <label for="title">Title:</label>
        <input type="text" name="title" required>
        <label for="content">Content:</label>
        <textarea name="content" rows="10" required></textarea>
        <button type="submit">Publish Blog</button>
    </form>
    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
