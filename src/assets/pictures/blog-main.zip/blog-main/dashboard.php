<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to login if not logged in
    exit();
}

$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>
<body>
    <h1>Welcome to Your Dashboard</h1>

    <?php if ($role == 'admin'): ?>
        <!-- Admin view -->
        <h2>Admin Options</h2>
        <a href="create-blog.php">Create New Blog</a>
        <h3>Manage Blogs</h3>
        <a href="manage-blogs.php">Manage Existing Blogs</a>
    <?php endif; ?>

    <!-- Everyone can view blogs -->
    <h2>Blogs</h2>
    <div class="blogs">
        <?php
        $stmt = $pdo->query("SELECT * FROM blogs ORDER BY created_at DESC");
        while ($row = $stmt->fetch()) {
            echo "<div class='blog'>";
            echo "<h3>" . htmlspecialchars($row['title']) . "</h3>";
            echo "<p>" . htmlspecialchars($row['content']) . "</p>";
            echo "<small>By: " . htmlspecialchars($row['author']) . " on " . $row['created_at'] . "</small>";
            echo "</div>";
        }
        ?>
    </div>

    <a href="logout.php">Logout</a>
</body>
</html>
