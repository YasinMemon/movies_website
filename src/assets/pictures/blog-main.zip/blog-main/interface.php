<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Admin</title>
    <link rel="stylesheet" href="./css/interface.css">
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>my demo</h2>
            <button class="new-post-btn">+ NEW POST</button>
        </div>
        <ul class="menu">
            <li><a href="#">Posts</a></li>
            <li><a href="#">Stats</a></li>
            <li><a href="#">Comments</a></li>
            <li><a href="#">Earnings</a></li>
            <li><a href="#">Pages</a></li>
            <li><a href="#">Layout</a></li>
            <li><a href="#">Theme</a></li>
            <li><a href="#">Settings</a></li>
            <li><a href="#">Reading List</a></li>
        </ul>
        <div class="view-blog">
            <a href="#">View blog</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <input type="text" placeholder="Search posts" class="search-bar">
        </div>

        <div class="post-list">
            <div class="post-header">
                <h3>All (1)</h3>
                <button class="manage-btn">MANAGE</button>
            </div>
            
            <!-- PHP Dynamic Post Loading -->
            <?php
                // Sample data for blog post
                $post = [
                    'title' => 'My blog',
                    'published_date' => 'Apr 3',
                    'author' => 'anas shaikh',
                    'comments' => 1,
                    'views' => 5
                ];
            ?>

            <div class="post-item">
                <div class="post-info">
                    <h4><?php echo $post['title']; ?></h4>
                    <p>Published · <?php echo $post['published_date']; ?></p>
                </div>
                <div class="post-meta">
                    <span><?php echo $post['author']; ?></span>
                    <span><i class="comment-icon"></i><?php echo $post['comments']; ?></span>
                    <span><i class="view-icon"></i><?php echo $post['views']; ?></span>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
